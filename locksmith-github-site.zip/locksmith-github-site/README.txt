LOCKSMITH WEBSITE - GITHUB UPLOAD

Files:
- index.html   = Homepage
- about.html   = About Us
- contact.html = Contact Us

GitHub Pages:
1. Upload all three HTML files to the repository root (same level).
2. Make sure the homepage is named exactly index.html.
3. Enable Settings > Pages > Deploy from branch > main > /(root).
4. Open the GitHub Pages URL after deployment.

The navigation is connected between Home, About and Contact.
